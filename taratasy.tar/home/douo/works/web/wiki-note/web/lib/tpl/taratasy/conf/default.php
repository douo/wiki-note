<?php
/*
 * default configuration settings
 *
 */

$conf['discussionPage']   = 'discussion:@ID@';
$conf['userPage']         = 'user:@USER@:';
$conf['sidebarID']        = 'sidebar';
$conf['hideTools']        =  0;
$conf['nsWidth']          = "drafts 100% 26em;notes 100% 26em";

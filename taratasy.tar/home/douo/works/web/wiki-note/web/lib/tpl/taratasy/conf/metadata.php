<?php
/*
 * configuration metadata
 *
 */

$meta['discussionPage']   = array('string');
$meta['userPage']         = array('string');
$meta['sidebarID']        = array('string');
$meta['hideTools']        = array('onoff');
$meta['nsWidth']          = array('string');

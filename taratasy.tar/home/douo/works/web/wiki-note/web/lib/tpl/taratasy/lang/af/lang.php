<?php
/**
 * Afrikaans language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Bespreking';
$lang['back_to_article'] = 'Terug na die artikel';
$lang['userpage']        = 'Gebruikersbladsy';

//Setup VIM: ex: et ts=2 :

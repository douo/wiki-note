<?php
/**
 * Arabic language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'نقاش';
$lang['back_to_article'] = 'عودة إلى المقالة';
//العودة إلى المقال
$lang['userpage']        = 'صفحة مستخدم';

//Setup VIM: ex: et ts=2 :

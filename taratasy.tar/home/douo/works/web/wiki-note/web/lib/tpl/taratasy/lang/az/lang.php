<?php
/**
 * Azerbaijani language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Müzakirə';
$lang['back_to_article'] = 'Geri makalenin'; // Məqalədə qayıt
$lang['userpage']      = 'İstifadəçi səhifəsi';

//Setup VIM: ex: et ts=2 :

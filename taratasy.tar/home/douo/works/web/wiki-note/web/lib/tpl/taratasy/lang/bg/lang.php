<?php
/**
 * Bulgarian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Беседа';
$lang['back_to_article'] = 'Обратно към статията';
$lang['userpage']        = 'Потребител';

//Setup VIM: ex: et ts=2 :

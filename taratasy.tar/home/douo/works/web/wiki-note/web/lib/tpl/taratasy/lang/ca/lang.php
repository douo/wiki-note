<?php
/**
 * Catalan language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discussió';
$lang['back_to_article'] = 'Tornar al article';
$lang['userpage']        = "Pàgina d'usuari";


//Setup VIM: ex: et ts=2 :

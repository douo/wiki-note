<?php
/**
 * Czech language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Diskuse';
$lang['back_to_article'] = 'Zpet na clánek';
$lang['userpage']        = 'Uživatelova stránka';

//Setup VIM: ex: et ts=2 :

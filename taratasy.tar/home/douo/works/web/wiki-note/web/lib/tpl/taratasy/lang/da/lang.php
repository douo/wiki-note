<?php
/**
 * Danish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Diskussion';
$lang['back_to_article'] = 'Tilbage til artiklen';
$lang['userpage']        = 'Brugerside';

//Setup VIM: ex: et ts=2 :


<?php
/**
 * Greek language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Συζήτηση';
$lang['back_to_article'] = 'Πίσω στα άρθρα';
$lang['userpage']        = 'Σελίδα χρήστη';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * English language file for template
 *
 */

$lang['discussion']        = 'Discussion';
$lang['back_to_article']   = 'Back to article';
$lang['userpage']          = 'User page';

/* accessibility headlines */
$lang['user_tools']        = 'User Tools';
$lang['site_tools']        = 'Site Tools';
$lang['page_tools']        = 'Page Tools';
$lang['skip_to_content']   = 'skip to content';


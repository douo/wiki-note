<?php
/**
 * English language file for config
 *
 */

$lang['discussionPage']   = 'Discussion page (leave empty to disable discussions)';
$lang['userPage']         = 'User page (leave empty to disable user pages)';
$lang['sidebarID']        = 'page name of page included in sidebar';
$lang['hideTools']        = 'Hide tools when not logged in?';
$lang['nsWidth']          = 'Define site and sidebar width according to namespace.  Syntax: "namespace site-width sidebar-width", you can add other namespaces also, using a semicolon to separate';



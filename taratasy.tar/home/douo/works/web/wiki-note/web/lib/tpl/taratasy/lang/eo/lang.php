<?php
/**
 * Esperantiga dosiero
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = 'Diskuto';
$lang['userpage']     = 'Pago de uzanto';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * Spanish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discusión';
$lang['back_to_article'] = 'Volver al artículo';
$lang['userpage']        = 'Página de usuario';

//Setup VIM: ex: et ts=2 :

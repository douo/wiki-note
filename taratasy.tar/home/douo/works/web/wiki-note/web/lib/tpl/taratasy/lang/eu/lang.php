<?php
/**
 * Basque language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Eztabaida';
$lang['back_to_article'] = 'Bueltatu';
$lang['userpage']        = 'Lankide orrialdea';//Erabiltzaile orrialdea

//Setup VIM: ex: et ts=2 :

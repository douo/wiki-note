<?php
/**
 * Persian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'بحث';
$lang['back_to_article'] = 'برگشت به مقاله';
$lang['userpage']        = 'صفحهٔ کاربر';

//Setup VIM: ex: et ts=2 :

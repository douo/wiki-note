<?php
/**
 * French language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discussion';
$lang['back_to_article'] = "Retour à l'article";
$lang['userpage']        = 'Page utilisateur';

//Setup VIM: ex: et ts=2 :

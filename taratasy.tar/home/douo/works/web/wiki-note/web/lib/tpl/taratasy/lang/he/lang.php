<?php
/**
 * Hebrew language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'שיחה';
$lang['back_to_article'] = 'חזור אל המאמר';
$lang['userpage']          = 'דף משתמש';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * Hindi language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'चर्चा';
$lang['back_to_article'] = 'वापस लेख करने के लिए';
$lang['userpage']        = 'सदस्य';

//Setup VIM: ex: et ts=2 :

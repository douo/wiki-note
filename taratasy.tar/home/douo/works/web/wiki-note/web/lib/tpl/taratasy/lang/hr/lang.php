<?php
/**
 * Croatian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Razgovor';
$lang['back_to_article'] = 'Natrag na clanak';
$lang['userpage']        = 'Stranica suradnika';

//Setup VIM: ex: et ts=2 :

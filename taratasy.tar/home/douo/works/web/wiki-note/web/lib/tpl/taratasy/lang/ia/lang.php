<?php
/**
 * Interlingua language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discussion';
$lang['userpage']        = 'Pagina de usator';

//Setup VIM: ex: et ts=2 :

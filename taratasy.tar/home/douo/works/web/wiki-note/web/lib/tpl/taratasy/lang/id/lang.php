<?php
/**
 * Indonesian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Pembicaraan';
$lang['back_to_article'] = 'Kembali ke artikel';
$lang['userpage']        = 'Pengguna';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * Icelandic language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Spjall';
$lang['back_to_article'] = 'Til baka á greinar';
$lang['userpage']        = 'Notandi';

//Setup VIM: ex: et ts=2 :

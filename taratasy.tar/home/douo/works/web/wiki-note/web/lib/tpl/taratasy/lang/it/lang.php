<?php
/**
 * Italian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discussione';
$lang['back_to_article'] = 'Torna all\'articolo';
$lang['userpage']        = 'Pagina utente';

//Setup VIM: ex: et ts=2 :

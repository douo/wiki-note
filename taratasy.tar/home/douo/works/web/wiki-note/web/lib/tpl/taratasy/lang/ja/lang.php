<?php
/**
 * Japanese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = '議論';
$lang['back_to_article'] = '戻る記事へ';
$lang['userpage']        = '利用者ページ';

//Setup VIM: ex: et ts=2 :

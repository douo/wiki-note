<?php
/**
 * Khmer language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'ការពិភាក្សា';
$lang['userpage']        = 'ទំព័រអ្នកប្រើប្រាស់';

//Setup VIM: ex: et ts=2 :

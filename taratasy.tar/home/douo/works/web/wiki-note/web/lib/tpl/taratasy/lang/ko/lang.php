<?php
/**
 * Korean language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']   = '토론';
$lang['back_to_article'] = '위로 기사';
$lang['userpage']       = '사용자 문서';

//Setup VIM: ex: et ts=2 :

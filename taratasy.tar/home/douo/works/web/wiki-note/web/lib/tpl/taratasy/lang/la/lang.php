<?php
/**
 * Latin language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Disputatio';
$lang['userpage']        = 'Pagina usoris';

//Setup VIM: ex: et ts=2 :

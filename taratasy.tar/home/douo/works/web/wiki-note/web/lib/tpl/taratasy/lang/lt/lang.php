<?
/**
 * Lithuanian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Aptarimas';
$lang['back_to_article'] = 'Atgal i straipsni';
$lang['userpage']        = 'Naudotojo puslapis';

//Setup VIM: ex: et ts=2 :
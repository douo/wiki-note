<?
/**
 * Latvian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
*/

$lang['discussion']      = 'Diskusija';
$lang['back_to_article'] = 'Atpakaļ uz rakstu';
$lang['userpage']        = 'Lietotāja lapa';

//Setup VIM: ex: et ts=2 :
<?php
/**
 * Macedonian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Разговор';
$lang['back_to_article'] = 'Назад кон статијата';
$lang['userpage']        = 'Корисник';

//Setup VIM: ex: et ts=2 :

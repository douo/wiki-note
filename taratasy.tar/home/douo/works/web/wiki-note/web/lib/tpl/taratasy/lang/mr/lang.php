<?php
/**
 * Marathi language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'चर्चा';
$lang['userpage']        = 'सदस्य पान';

//Setup VIM: ex: et ts=2 :

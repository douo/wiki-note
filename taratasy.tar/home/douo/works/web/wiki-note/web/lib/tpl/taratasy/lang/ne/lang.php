<?php
/**
 * Nepali language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'वार्तालाप';
$lang['userpage']        = 'प्रयोगकर्ता पृष्ठ';

//Setup VIM: ex: et ts=2 :

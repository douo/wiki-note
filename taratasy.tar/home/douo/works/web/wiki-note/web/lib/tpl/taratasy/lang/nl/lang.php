<?php
/**
 * Dutch language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Overleg';
$lang['back_to_article'] = 'Terug naar artikel';
$lang['userpage']        = 'Gebruikerspagina';

//Setup VIM: ex: et ts=2 :
<?php
/**
 * Polish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Dyskusja';
$lang['back_to_article'] = 'Powrót do artykułu';
$lang['userpage']        = 'Strona użytkownika';

//Setup VIM: ex: et ts=2 :

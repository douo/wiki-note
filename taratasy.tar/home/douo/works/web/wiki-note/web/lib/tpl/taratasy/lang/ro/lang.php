<?php
/**
 * Romanian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Discuție';
$lang['back_to_article'] = 'Înapoi la articol';
$lang['userpage']        = 'Pagină de utilizator';

//Setup VIM: ex: et ts=2 :

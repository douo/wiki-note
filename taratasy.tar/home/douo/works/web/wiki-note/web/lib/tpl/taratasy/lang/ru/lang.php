<?php
/**
 * Russian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Обсуждение';
$lang['back_to_article'] = 'Назад к статье';
$lang['userpage']        = 'Участник';

//Setup VIM: ex: et ts=2 :

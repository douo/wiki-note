<?php
/**
 * Slovak language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Diskusia';
$lang['back_to_article'] = 'Späť na článok';
$lang['userpage']        = 'Stránka používateľa';

//Setup VIM: ex: et ts=2 :

<?
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Pogovor';
$lang['back_to_article'] = 'Nazaj na članek';
$lang['userpage']        = 'Uporabniška stran';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * Albanian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Diskutimet';
$lang['back_to_article'] = 'Kthehu tek artikulli';
$lang['userpage']        = 'Përdoruesi';

//Setup VIM: ex: et ts=2 :

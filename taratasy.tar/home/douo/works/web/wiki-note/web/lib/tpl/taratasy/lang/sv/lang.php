<?php
/**
 * Swedish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Diskussion';
$lang['back_to_article'] = 'Tillbaka till artikeln';
$lang['userpage']        = 'Användarsida';

//Setup VIM: ex: et ts=2 :

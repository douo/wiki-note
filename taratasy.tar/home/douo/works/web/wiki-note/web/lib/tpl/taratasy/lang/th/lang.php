<?php
/**
 * Thai language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'อภิปราย';
$lang['back_to_article'] = 'กลับไปที่บทความ';
$lang['userpage']        = 'หน้าผู้ใช้';

//Setup VIM: ex: et ts=2 :

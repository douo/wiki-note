<?php
/**
 * Turkish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Tartışma';
$lang['back_to_article'] = 'Geri makalenin';
$lang['userpage']        = 'Kullanıcı sayfası';

//Setup VIM: ex: et ts=2 :

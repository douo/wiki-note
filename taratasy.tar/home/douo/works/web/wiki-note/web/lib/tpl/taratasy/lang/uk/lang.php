<?php
/**
 * Ukrainian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Обговорення';
$lang['back_to_article'] = 'Назад до статті';
$lang['userpage']        = 'Сторінка користувача';

//Setup VIM: ex: et ts=2 :

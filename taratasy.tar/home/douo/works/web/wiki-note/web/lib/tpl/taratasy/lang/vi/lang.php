<?php
/**
 * Vietnamese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = 'Thảo luận';
$lang['back_to_article'] = 'Trở lại bài viết';
$lang['userpage']        = 'Thành viên';

//Setup VIM: ex: et ts=2 :

<?php
/**
 * Chinese (Traditional) language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = '討論';
$lang['back_to_article'] = '回到文章';
$lang['userpage']        = '用戶頁面'; // 使用者頁面

//Setup VIM: ex: et ts=2 :

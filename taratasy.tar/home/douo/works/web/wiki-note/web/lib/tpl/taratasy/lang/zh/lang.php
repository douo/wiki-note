<?php
/**
 * Chinese (Simplified) language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$lang['discussion']      = '讨论';
$lang['back_to_article'] = '回到文章';
$lang['userpage']        = '用户页面';

//Setup VIM: ex: et ts=2 :

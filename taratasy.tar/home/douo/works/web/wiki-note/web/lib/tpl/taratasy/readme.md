Taratasy Template for Dokuwiki
====

http://www.dokuwiki.org/template:taratasy

  - version: 2011-07-28
  - author: Symon Bent <hendrybadao@gmail.com>


*Based substantially on the:*

Starter Template for DokuWiki
----
http://www.dokuwiki.org/template:starter

  - version: 2011-02-20
  - author: Anika Henke <anika@selfthinker.org>
